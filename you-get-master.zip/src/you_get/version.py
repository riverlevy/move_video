#!/usr/bin/env python

script_name = 'you-get'
__version__ = '0.4.1040'
